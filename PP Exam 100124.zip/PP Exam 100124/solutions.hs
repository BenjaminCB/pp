-- Name:
-- AAU mail address:
-- Study number:


-- PROBLEM 1

-- 1.1

-- 1.2

-- 1.3

-- PROBLEM 2

-- 2.1

-- 2.2

-- 2.3

-- PROBLEM 3

-- 3.1

-- 3.2

-- PROBLEM 4

-- 4.1

-- 4.2

-- 4.3

-- PROBLEM 5

-- 5.1

-- 5.2

-- 5.3

-- 5.4

-- PROBLEM 6

-- 6.1

-- 6.2


